﻿using Microsoft.AspNetCore.Mvc;
using MVCWebCoreApp.Data;
using MVCWebCoreApp.Models;

namespace MVCWebCoreApp.Controllers
{
    public class CategoryController : Controller
    {
        private readonly AppDBContext _appDB;

        public CategoryController(AppDBContext appDB)
        {
            _appDB = appDB;
        }
        public IActionResult Index()
        {
            IEnumerable<Category> categories = new List<Category>();

            categories = _appDB.Categories.ToList().OrderBy(x => x.DisplayOrder);
            return View(categories);
        }

        public IActionResult Create()
        {
            Category category = new Category();
            return View(category);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Category category)
        {
            if (ModelState.IsValid)
            {
                if (!CategoryExists(category))
                {
                    _appDB.Categories.Add(category);
                    _appDB.SaveChanges();
                    return RedirectToAction("Index");
                }
                else
                {
                    ModelState.AddModelError("CategoryName", "Category Name already exists");
                }
            }

            return View(category);
        }

        public IActionResult Edit(Guid? Id)
        {
            
            try
            {
                if (Id == null)
                {
                    return BadRequest();
                }
                 var categoryDB = _appDB.Categories.FirstOrDefault(x => x.Id == Id);
                if (categoryDB == null) { return NotFound(); }
                return View("Create", categoryDB);
            }
            catch (Exception)
            {

                return View();
            }
           
            

        }
        
        public IActionResult DeleteCategory(Guid? Id)
        {
            if (Id == null)
            {
                return BadRequest();
            }
            var categoryDB = _appDB.Categories.Find(Id);
            
            if (categoryDB == null) { return NotFound(); }
            _appDB.Remove(categoryDB);
            _appDB.SaveChanges();
            return RedirectToAction("Index");

        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Update(Category category)
        {
            if (ModelState.IsValid)
            {
                if (!CategoryExists(category))
                {
                    _appDB.Categories.Update(category);
                    _appDB.SaveChanges();
                    return RedirectToAction("Index");
                }
                else
                {
                    ModelState.AddModelError("CategoryName", "Category Name already exists");
                }
            }

            return View(category);

        }

        private bool CategoryExists(Category category)
        {
            bool returnvalue = false;
            returnvalue = _appDB.Categories.Where(x => x.CategoryName == category.CategoryName).Any();
            return returnvalue;
        }

        


    }
}
