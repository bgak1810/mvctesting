﻿using Newtonsoft.Json.Serialization;
using System.ComponentModel.DataAnnotations;

namespace MVCWebCoreApp.Models
{
    public class Category
    {
        [Key]
        public Guid Id { get; set; }
        [Required]
        
        public int CategoryId { get; set; }
        [Required]
        public string CategoryName { get; set; } = string.Empty;
        [Required]
        public int DisplayOrder { get; set;} = 0;

       

    }
}
